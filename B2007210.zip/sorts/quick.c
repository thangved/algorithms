#include <stdio.h>

typedef struct
{
    int key;
    float other;
} RecordType;

void swap(RecordType *a, RecordType *b)
{
	RecordType c = *a;
	*a = *b;
	*b = c;
}

void readdata(RecordType data[], int *len, char *filepath)
{
	FILE *f;
	f = fopen(filepath, "r");
    int key;
    float other;
    while(fscanf(f, "%d%f", &key, &other) != EOF)
    {
    	RecordType t = {key, other};
    	data[*len] = t;
    	*len = *len + 1;
	}
    
    fclose(f);
}

void printrecords(const RecordType data[], int len)
{
    int i;
    puts("#\tkey\tother");
    for (i = 0; i < len; i++)
        printf("%d\t%d\t%.2f\n", i+1, data[i].key, data[i].other);
}

int findpivot(const RecordType data[], int begin, int end)
{
    int i;
    for (i = begin; i <= end; i++)
        if (data[begin].key != data[i].key)
            return data[begin].key > data[i].key ? begin : i;
    return -1;
}

int partition(RecordType data[], int pl, int pr, int pivot)
{
    while (pl <= pr)
    {
        while (data[pl].key < pivot)
            pl++;
        while (data[pr].key >= pivot)
            pr--;
        if (pl < pr)
            swap(&data[pl], &data[pr]);
    }
    return pl;
}

void quicksort(RecordType data[], int begin, int end)
{
    int pid = findpivot(data, begin, end);
    if (pid == -1)
        return;

    int partitionindex = partition(data, begin, end, data[pid].key);
    quicksort(data, 0, partitionindex - 1);
    quicksort(data, partitionindex, end);
}

int main()
{
    RecordType data[100];
    int len = 0;
    puts("Quick sort");
    readdata(data, &len, "data.txt");
    puts("Before sort");
    printrecords(data, len);
    puts("---");
    puts("Sorted!!!");
    quicksort(data, 0, len - 1);
    printrecords(data, len);
    return 0;
}


