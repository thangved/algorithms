#include <stdio.h>

typedef struct
{
    int key;
    float other;
} RecordType;

void swap(RecordType *a, RecordType *b)
{
	RecordType c = *a;
	*a = *b;
	*b = c;
}

void readdata(RecordType data[], int *len, char *filepath)
{
	FILE *f;
	f = fopen(filepath, "r");
    int key;
    float other;
    while(fscanf(f, "%d%f", &key, &other) != EOF)
    {
    	RecordType t = {key, other};
    	data[*len] = t;
    	*len = *len + 1;
	}
    
    fclose(f);
}

void printrecords(const RecordType data[], int len)
{
    int i;
    puts("#\tkey\tother");
    for (i = 0; i < len; i++)
        printf("%d\t%d\t%.2f\n", i+1, data[i].key, data[i].other);
}

void selectionsort(RecordType data[], int len)
{
    int i;
    for (i = 0; i < len - 1; i++)
    {
        int minindex = i;
        int j;
        for (j = i + 1; j < len; j++)
            if (data[minindex].key > data[j].key)
                minindex = j;

        swap(&data[i], &data[minindex]);
    }
}

int main()
{
    RecordType data[100];
    int len = 0;
    puts("Selection sort");
    readdata(data, &len, "data.txt");
    puts("Before sort");
    printrecords(data, len);
    puts("---");
    puts("Sorted!!!");
    selectionsort(data, len);
    printrecords(data, len);
    return 0;
}
