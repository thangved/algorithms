#include <stdio.h>

typedef struct
{
    int key;
    float other;
} RecordType;

void swap(RecordType *a, RecordType *b)
{
	RecordType c = *a;
	*a = *b;
	*b = c;
}

void readdata(RecordType data[], int *len, char *filepath)
{
	FILE *f;
	f = fopen(filepath, "r");
    int key;
    float other;
    while(fscanf(f, "%d%f", &key, &other) != EOF)
    {
    	RecordType t = {key, other};
    	data[*len] = t;
    	*len = *len + 1;
	}
    
    fclose(f);
}

void printrecords(const RecordType data[], int len)
{
    int i;
    puts("#\tkey\tother");
    for (i = 0; i < len; i++)
        printf("%d\t%d\t%.2f\n", i+1, data[i].key, data[i].other);
}

void insertionsort(RecordType data[], int len)
{
    int i;
    for (i = 0; i < len; i++)
    {
        int minindex = i;
        int j = i;
        while (data[j].key < data[j - 1].key && j > 0)
        {
            swap(&data[j], &data[j - 1]);
            j--;
        }
    }
}

int main()
{
    RecordType data[100];
    int len = 0;
    puts("Insertion sort");
    readdata(data, &len, "data.txt");
    puts("Before sort");
    printrecords(data, len);
    puts("---");
    puts("Sorted!!!");
    insertionsort(data, len);
    printrecords(data, len);
    return 0;
}

