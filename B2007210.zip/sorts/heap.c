#include <stdio.h>

typedef struct
{
    int key;
    float other;
} RecordType;

void swap(RecordType *a, RecordType *b)
{
	RecordType c = *a;
	*a = *b;
	*b = c;
}

void readdata(RecordType data[], int *len, char *filepath)
{
	FILE *f;
	f = fopen(filepath, "r");
    int key;
    float other;
    while(fscanf(f, "%d%f", &key, &other) != EOF)
    {
    	RecordType t = {key, other};
    	data[*len] = t;
    	*len = *len + 1;
	}
    
    fclose(f);
}

void printrecords(const RecordType data[], int len)
{
    int i;
    puts("#\tkey\tother");
    for (i = 0; i < len; i++)
        printf("%d\t%d\t%.2f\n", i+1, data[i].key, data[i].other);
}

void pushdown(RecordType data[], int begin, int end)
{
    while (begin <= (end - 1) / 2)
    {
        if (begin * 2 + 1 == end)
        {
            if (data[begin].key > data[end].key)
                swap(&data[begin], &data[end]);
            break;
        }

        if ((data[begin].key > data[begin * 2 + 1].key) && (data[begin * 2 + 1].key <= data[begin * 2 + 2].key))
        {
            swap(&data[begin], &data[begin * 2 + 1]);
            begin = begin * 2 + 1;
            continue;
        }

        if ((data[begin].key > data[begin * 2 + 2].key) && (data[begin * 2 + 1].key > data[begin * 2 + 2].key))
        {
            swap(&data[begin], &data[begin * 2 + 2]);
            begin = begin * 2 + 2;
            continue;
        }

        break;
    }
}

void heapsort(RecordType data[100], int len)
{
    int i;
    for (i = (len - 2) / 2; i >= 0; i--)
        pushdown(data, i, len - 1);

    for (i = len - 1; i >= 2; i--)
    {
        swap(&data[0], &data[i]);
        pushdown(data, 0, i - 1);
    }
    swap(&data[0], &data[1]);
}

int main()
{
    RecordType data[100];
    int len = 0;
    puts("Quick sort");
    readdata(data, &len, "data.txt");
    puts("Before sort");
    printrecords(data, len);
    puts("---");
    puts("Sorted!!!");
    heapsort(data, len);
    printrecords(data, len);
    return 0;
}

