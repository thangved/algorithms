#include <iostream>

using namespace std;

typedef struct
{
    int key;
    float other;
} RecordType;

void readdata(RecordType data[], int &len, const char *filepath = "data.txt")
{
	FILE *f;
	f = fopen(filepath, "r");
    len = 0;
    int key;
    float other;
    while(fscanf(f, "%d%f", &key, &other) != EOF)
    {
    	RecordType t = {key, other};
    	data[len++] = t;
	}
    
    fclose(f);
}

void selectionsort(RecordType data[], int len)
{
    int i;
    for (i = 0; i < len - 1; i++)
    {
        int minindex = i;
        int j;
        for (j = i + 1; j < len; j++)
            if (data[minindex].key > data[j].key)
                minindex = j;

        swap<RecordType>(data[i], data[minindex]);
    }
}

void printrecords(const RecordType data[], int len)
{
    int i;
    for (i = 0; i < len; i++)
        cout << data[i].key << "\t" << data[i].other << endl;
}

int main()
{
    RecordType data[100];
    int len;
    cout << "Selection Sort" << endl;
    readdata(data, len);
    cout << "Example array" << endl;
    printrecords(data, len);
    cout << endl
         << "Sorting..." << endl;
    selectionsort(data, len);
    cout << "Sorted!!!" << endl;
    printrecords(data, len);
    return 0;
}
